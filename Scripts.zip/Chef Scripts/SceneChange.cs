﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChange : MonoBehaviour {

    float levelLoadDelay = 2f;

    public void LevelComplete()
    {
        Debug.Log("You completed this level!");
        Invoke("LoadNextLevel", levelLoadDelay);
    }

    public void RestartLevel()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex);
    }

    public void LoadNextLevel()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;

        int nextSceneIndex = currentSceneIndex + 1;
        if (nextSceneIndex == SceneManager.sceneCountInBuildSettings)
        {
            nextSceneIndex = 0; // loop back to start
        }

        SceneManager.LoadScene(nextSceneIndex); // todo allow for more than 2 levels
    }

    /*
     * Returns one less than current scene index.
     */
    public int GetCurrentSceneIndex()
    {
        return SceneManager.GetActiveScene().buildIndex - 1;
    }
}
