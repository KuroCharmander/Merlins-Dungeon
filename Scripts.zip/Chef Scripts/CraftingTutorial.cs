﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CraftingTutorial : MonoBehaviour {

    public GameObject[] step1 = null;
    public GameObject[] step2 = null;
    public GameObject[] step3 = null;
    public GameObject[] step4 = null;
        
    int completedTasks = 0;
    Button exitButton;
    Button synthesizeButton;

    bool step1Complete, completedTutorial = false;

	// Use this for initialization
	void Start () {
        Deactivate(step1);
        Deactivate(step2);
        Deactivate(step3);
        Deactivate(step4);
    }

    // Update is called once per frame
    void Update () {
        if (GameObject.Find("Crafting Panels").transform.Find("Synthesis").gameObject.activeSelf && !step1Complete)
        {
            Display(step1);
            exitButton = GameObject.Find("Crafting Panels").transform.Find("Exit Button").GetComponent<Button>();
            exitButton.interactable = false;
            synthesizeButton = GameObject.Find("Crafting Panels").transform.Find("Synthesize Button").GetComponent<Button>();
            synthesizeButton.interactable = false;
        }
        else if (GameObject.Find("Crafting Panels").transform.Find("Synthesis").gameObject.activeSelf && completedTutorial)
            Display(step4);
        
        if (completedTasks == 0)
            CompleteStep1();
        else if (completedTasks == 1)
            CompleteStep2();
        else if (completedTasks == 2)
            CompleteStep3();
        else if (completedTasks == 3)
            CompleteStep4();
	}


    void Display(GameObject[] currStep)
    {
        foreach (GameObject o in currStep)
            o.SetActive(true);
    }

    void Deactivate(GameObject[] step)
    {
        foreach (GameObject o in step)
            o.SetActive(false);
    }

    void CompleteStep1()
    {
        if (GameObject.Find("Crafting Panels").transform.Find("Recipes").transform.Find("Oxygen Gas").transform.Find("Science Info").gameObject.activeSelf)
        {
            completedTasks++;
            step1Complete = true;
            Deactivate(step1);
            Display(step2);
        }
    }

    void CompleteStep2()
    {
        foreach (KeyValuePair<string, int> elementMap in ElementHandler.elementMap)
        {
            if (elementMap.Key == "Oxygen" && elementMap.Value == 2)
            {
                completedTasks++;
                Deactivate(step2);
                Display(step3);
                synthesizeButton.interactable = true;
            }
        }
    }

    void CompleteStep3()
    {
        if (GameObject.Find("Elements").transform.Find("Oxygen Gas"))
        {
            completedTasks++;
            Deactivate(step3);
            exitButton.interactable = true;
            Display(step4);
        }
    }

    void CompleteStep4()
    {
        if (!GameObject.Find("Crafting Panels").transform.Find("Synthesis").gameObject.activeSelf)
        {
            completedTutorial = true;
            Deactivate(step4);
        }
    }
}
