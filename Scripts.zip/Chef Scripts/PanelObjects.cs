﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelObjects : MonoBehaviour {

    public static void ClearSynthesisPanel(bool success)
    {
        if (!success)
        {
            foreach (KeyValuePair<string, int> elementMap in ElementHandler.elementMap)
            {
                GameObject element = GameObject.Find("Elements").transform.Find(elementMap.Key).gameObject;
                ElementDisplay elementDisplay = element.GetComponent<ElementDisplay>();
                string displayTextStr = elementDisplay.quantityText.text;
                int displayInt = int.Parse(displayTextStr);
                displayInt += elementMap.Value;
                string displayString = displayInt.ToString();
                elementDisplay.quantityText.text = displayString;
            }
        }

        GameObject synthesisPanel = GameObject.Find("Synthesis");
        foreach (Transform child in synthesisPanel.transform)
        {
            GameObject.Destroy(child.gameObject);
        }
        ElementHandler.elementMap.Clear();
    }

    public static void InstantiateProduct(string name, string instantiatePanel)
    {
        GameObject currentProduct = GameObject.Find(name);
        GameObject clonedProduct = Instantiate(currentProduct);
        GameObject panel = GameObject.Find(instantiatePanel);
        clonedProduct.transform.SetParent(panel.transform);
        panel.transform.Find(name + "(Clone)").name = name;
        clonedProduct.transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);
    }
}
