﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProductDisplay : MonoBehaviour {

    public ScriptableProduct product;

    public Text productNameText;
    public Image backgroundImage;


	// Use this for initialization
	void Start () {
        productNameText.text = product.productName;
        backgroundImage.sprite = product.background;
	}
	

}
