﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ElementDisplay : MonoBehaviour {

    public Element element;

    public Text nameText;
    public Text elementWrap; //To put a textbox on top of the whole object. Allows interactions if place dragged element on another element object.
    public Image backgroundImage;
    public Text quantityText;


    // Use this for initialization
    void Start () {

        nameText.text = element.elementName;
        elementWrap.text = element.elementName;
        backgroundImage.sprite = element.background;
        quantityText.text = element.quantity.ToString();
	}
}
