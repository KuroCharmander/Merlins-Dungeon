﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Synthesizer : MonoBehaviour {//, IPointerDownHandler {

    SceneChange sceneChange = new SceneChange();
    float levelLoadDelay = 2f;

    MoleculesFactory factory = new MoleculesFactory();
    int order = 0;
    bool success = false;

    ExitCrafting exitCrafting;

    // Use this for initialization
    void Start () {
        factory.InitializeMoleculeList();
        exitCrafting = GameObject.Find("Exit Button").GetComponent<ExitCrafting>();
    }

    //public void OnPointerDown(PointerEventData eventData)
    public void Synthesize()
    {
        CheckSynthesis();
        PanelObjects.ClearSynthesisPanel(success);
        success = false;
    }

    void CheckSynthesis()
    {
        foreach (string e in ElementHandler.elementMap.Keys)
        {
            if (factory.molecules.ContainsKey(e))
                success = SynthesizeReactions();
            else
                success = SynthesizeMolecules();
            break;
        }
    }

    bool SynthesizeMolecules()
    {
        //KeyValuePair<string, Dictionary<string, int>>
        foreach (var m in factory.molecules)
        {
            int equal = 0;
                        
            foreach (KeyValuePair<string, int> e in ElementHandler.elementMap)
            {
                if (m.Value.Count == ElementHandler.elementMap.Count)
                {
                    if (m.Value.ContainsKey(e.Key) && m.Value[e.Key] == e.Value)
                        equal++;
                    else
                        break;
                }
                else
                {
                    break;
                }

                if (equal == m.Value.Count)
                {
                    PanelObjects.InstantiateProduct(m.Key, "Elements");
                    exitCrafting.CorrectMolecule(m.Key);
                    return true;
                }
            }
        }
        FailSequence();
        return false;
    }

    bool SynthesizeReactions()
    {
        //foreach (KeyValuePair<string, int> r in factory.reactions[i][1])
        foreach (var reaction in factory.reactions)
        {
            int equal = 0;

            foreach (var m in reaction.Value[1])
            {
                if (reaction.Value[1].Count == ElementHandler.elementMap.Count)
                {
                    if (ElementHandler.elementMap.ContainsKey(m.Key)
                        && m.Value == ElementHandler.elementMap[m.Key])
                        equal++;
                    else
                        break;
                }
                else
                {
                    break;
                }
            }
            if (equal == reaction.Value[1].Count)
            {
                foreach (var mol in reaction.Value[2])
                {
                    Debug.Log(mol.Key);
                    PanelObjects.InstantiateProduct(mol.Key, "Elements");
                    exitCrafting.CorrectMolecule(mol.Key);
                }
                Debug.Log("Finished synthesizing");
                return true;
            }
        }
        FailSequence();
        return false;
    }

    private void FailSequence()
    {
        Debug.Log("Failed");
        //if (levels.randomize) RandomMoleculeFail();
        StartCoroutine(SpecialFX.FailColourBlink());
    }
}
    /*
    void SynthesizeReactions()
    {
        int i = 0;
        //foreach (KeyValuePair<string, int> r in factory.reactions[i][1])
        foreach (var reaction in factory.reactions)
        {
            int equal = 0;

            foreach (var m in reaction[1])

            if (reaction[1].Count == ElementHandler.elementMap.Count)
            {
                if (ElementHandler.elementMap.ContainsKey(m.Key) 
                    && m.Value[e.Key] == e.Value)
                    equal++;
                else
                    break;
            }
            else
            {
                break;
            }

            if (equal == m.Value.Count)
            {
                PanelObjects.InstantiateProduct(e.Key, "Element");
                return;
            }
        }
    }
    /*

    /*
    void Synthesize(List<string> reagents)
    {
        int count = reagents.Capacity;
        int i = 0;

        foreach (string e in ElementHandler.elementMap.Keys)
        {
            if (reagents.Contains(e))
            {
                reagents.Remove(e);
                i++;
            }
            else
            {
                break;
            }
        }

        if (count == i)
        {
            Debug.Log("Successfully Synthesized!");

            foreach (string e in ElementHandler.elementMap.Keys)
            {
                if (levels.randomize)
                    RandomMoleculeSuccess(e);
                else
                    PanelObjects.InstantiateProduct(e, "Element");
            }

            order++;
            if (levels.randomize) InstantiateNext();
        }
        else
        {
            FailSequence();
        }
    }

    void Synthesize(Hashtable molecule, string moleculeName)
    {
        int count = molecule.Count;
        int i = 0;
        foreach (string e in ElementHandler.elementMap.Keys)
        {
            if (molecule.ContainsKey(e) && (int)molecule[e] == (int)ElementHandler.elementMap[e])
                i++;
            else
                break;
        }

        if (count == i)
        {
            Debug.Log("Successfully Synthesized!");
            order++;
            if (levels.randomize)
            {
                RandomMoleculeSuccess(moleculeName);
                InstantiateNext();
            }
            else
            {
                PanelObjects.InstantiateProduct(moleculeName, "Elements");
            }
        }
        else
        {
            FailSequence();
        }
    }

    */
