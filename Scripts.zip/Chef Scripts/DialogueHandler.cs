﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueHandler : MonoBehaviour {

    public GameObject dialoguePanel;

    // Use this for initialization
    public void InstantiateObjects()
    {
        dialoguePanel = GameObject.Find("Dialogue Panel").gameObject;
        dialoguePanel.SetActive(false);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
