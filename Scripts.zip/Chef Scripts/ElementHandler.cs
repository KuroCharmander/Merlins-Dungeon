﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public class ElementHandler : MonoBehaviour, IPointerDownHandler {
    
    public enum Slot { ELEMENT, PRODUCT };
    public Slot elementType = Slot.ELEMENT;
    public static Dictionary<string, int> elementMap = new Dictionary<string, int>();


    public void OnPointerDown(PointerEventData eventData)
    {
        if (GameObject.Find("Synthesis") != null)
        {
            GameObject clickedObj = this.gameObject;
            ElementDisplay elementDisplay = clickedObj.GetComponent<ElementDisplay>();
            string displayTextStr = elementDisplay.quantityText.text;
            int displayInt = int.Parse(displayTextStr);

            if (displayInt > 0)
            {

                displayInt -= 1;
                string displayString = displayInt.ToString();
                elementDisplay.quantityText.text = displayString;


                GameObject cloneClicked = Instantiate(GameObject.Find(clickedObj.name));
                cloneClicked.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                ElementDisplay cloneDisplay = cloneClicked.GetComponent<ElementDisplay>();
                ElementHandler cloneHandler = cloneClicked.GetComponent<ElementHandler>();
                cloneDisplay.enabled = false;
                //Debug.Log("before:" + cloneDisplay.quantityText.text);
                //cloneDisplay.quantityText.text = "";
                cloneClicked.GetComponent<ElementDisplay>().quantityText.text = "";
                //Debug.Log("after" + cloneDisplay.quantityText.text);
                cloneClicked.transform.SetParent(GameObject.Find("Synthesis").transform);



                string elementTag = this.tag;
                //Debug.Log(elementMap);
                if (!elementMap.ContainsKey(elementTag))
                    elementMap.Add(elementTag, 1);
                else
                    elementMap[elementTag]++; //elementMap[elementTag] + 1;
            }
            else
            {
                Debug.Log("Ran out of: " + clickedObj.name);
            }
        }
    }
}
