﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoPopup : MonoBehaviour {

    public GameObject popup;

    // Use this for initialization
    void Start() {

        if (popup != null)
        {
            popup.SetActive(false);
        }
    }

    public void ActivatePopup()
    {
        popup.SetActive(true);
    }

    void DeactivatePopup()
    {
        popup.SetActive(false);
    } 
}
