﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitCrafting : MonoBehaviour {

    public GameObject[] exitPrompt = null;
    SceneChange sceneChange = new SceneChange();

    // Use this for initialization
    void Start () {
        foreach (GameObject o in exitPrompt)
        o.SetActive(false);
    }

    // Update is called once per frame
    void Update () {
		
	}

    void ExitPrompt()
    {
        foreach (GameObject o in exitPrompt)
            o.SetActive(true);
    }

    public void CorrectMolecule(string product)
    {
        if (sceneChange.GetCurrentSceneIndex() == 1)
        {
            if (product == "Oxygen Gas")
            {
                SpecialFX.ColourBlink(GameObject.Find("Elements").transform.Find(product).gameObject);
            }
        }
        else if (sceneChange.GetCurrentSceneIndex() == 2)
        {
            if (product == "Water")
            {
                ExitPrompt();
                Debug.Log(GameObject.Find("Elements").transform.Find(product).gameObject);
                Debug.Log("Begin Blinking");
                SpecialFX.ColourBlink(GameObject.Find("Elements").transform.Find(product).gameObject);
                Debug.Log("End Blink");
            }
        }
        //Level 4
        else if (sceneChange.GetCurrentSceneIndex() == 3)
        {
            if (product == "Sodium Chloride")
            {
                ExitPrompt();
                SpecialFX.ColourBlink(GameObject.Find("Elements").transform.Find(product).gameObject);
            }
        }
    }
}
