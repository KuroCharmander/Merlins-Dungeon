﻿// Adapted from http://www.indiana.edu/~gamedev/2015/09/27/creating-a-visual-novel-in-unity/

using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
//using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public class DialogueParser : MonoBehaviour
{

    struct DialogueLine
    {
        public string name;
        public string content;
        public int pose;
        public string position;
        public string[] options;

        public DialogueLine(string Name, string Content, int Pose, string Position)
        {
            name = Name;
            content = Content;
            pose = Pose;
            position = Position;
            options = new string[0];
        }
    }

    List<DialogueLine> lines;
    [SerializeField] string scene;

    // Use this for initialization
    public void Parse()
    {
        // "Assets/SynthesisChef Assets/Dialogue/Dialogue1-1" for Scene 1, Dialogue Set 1
        // string file = "Assets/SynthesisChef Assets/Dialogue/Dialogue";
        // todo: change number accordingly
        // int scene = SceneManager.GetActiveScene().buildIndex - 1;
        // string sceneNum = scene.ToString();
        //sceneNum = Regex.Replace(sceneNum, "[^0-9]", "");
        Debug.Log("finding file");

        string file;
        if (Debug.isDebugBuild)
            file = "Assets/SynthesisChef Assets/Dialogue/Dialogue";
        else
            file = "Dialogue/Dialogue";
        file += scene;
        file += ".txt";

        Debug.Log("file found");
        lines = new List<DialogueLine>();

        LoadDialogue(file);
    }

    // Update is called once per frame
    void Update()
    {

    }

    void LoadDialogue(string filename)
    {
        string line;
        StreamReader r = new StreamReader(filename);

        using (r)
        {
            do
            {
                line = r.ReadLine();
                if (line != null)
                {
                    string[] lineData = line.Split(';');
                    if (lineData[0] == "Player")
                    {
                        DialogueLine lineEntry = new DialogueLine(lineData[0], "", 0, "");
                        lineEntry.options = new string[lineData.Length - 1];
                        for (int i = 1; i < lineData.Length; i++)
                        {
                            lineEntry.options[i - 1] = lineData[i];
                        }
                        lines.Add(lineEntry);
                    }
                    else
                    {
                        DialogueLine lineEntry = new DialogueLine(lineData[0], lineData[1], int.Parse(lineData[2]), lineData[3]);
                        lines.Add(lineEntry);
                    }
                }
            }
            while (line != null);
            r.Close();
        }
        Debug.Log("finished reading");

    }

    public string GetPosition(int lineNumber)
    {
        if (lineNumber < lines.Count)
        {
            return lines[lineNumber].position;
        }
        return "";
    }

    public string GetName(int lineNumber)
    {
        if (lineNumber < lines.Count)
        {
            return lines[lineNumber].name;
        }
        return "";
    }

    public string GetContent(int lineNumber)
    {
        if (lineNumber < lines.Count)
        {
            return lines[lineNumber].content;
        }
        return "";
    }

    public int GetPose(int lineNumber)
    {
        if (lineNumber < lines.Count)
        {
            return lines[lineNumber].pose;
        }
        return 0;
    }

    public string[] GetOptions(int lineNumber)
    {
        if (lineNumber < lines.Count)
        {
            return lines[lineNumber].options;
        }
        return new string[0];
    }

    public int GetNumLines()
    {
        return lines.Count;
    }

    public string GetScene()
    {
        return scene;
    }
}