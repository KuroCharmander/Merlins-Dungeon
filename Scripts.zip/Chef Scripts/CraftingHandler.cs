﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraftingHandler : MonoBehaviour {

    public GameObject synthesisPanel;
    public GameObject recipesPanel;
    public GameObject synthesisButton;
    public GameObject exitButton;
    public GameObject player;

	// Use this for initialization
	public void InstantiateObjects () {
        synthesisPanel = GameObject.Find("Synthesis").gameObject;
        recipesPanel = GameObject.Find("Recipes").gameObject;
        synthesisButton = GameObject.Find("Synthesize Button").gameObject;
        exitButton = GameObject.Find("Exit Button").gameObject;

        DeactivateCrafting();
            
    }
	
    public void DeactivateCrafting() {
        
        synthesisPanel.SetActive(false);
        recipesPanel.SetActive(false);
        synthesisButton.SetActive(false);
        exitButton.SetActive(false);
        if (player != null)
        {
            player.SetActive(true);
        }
        if (PlayerInteract.currentOtherObject != null)
        {
            PlayerInteract.currentOtherObject.SendMessage("ActivatePopUp");
            PlayerInteract.currentOtherObject = null;
        }

        
     }

    public void ExitCrafting() {

        DeactivateCrafting();

        if (GameObject.Find("Crafting Panels").transform.Find("Tutorial") != null)
        {
            GameObject.Find("Crafting Panels").transform.Find("Tutorial").gameObject.SetActive(false);
        }

        GameObjectActions.ResetPlayableObjects();
    }
}
