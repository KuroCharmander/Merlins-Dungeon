﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ElementDraggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{

    public Transform parentToReturnTo = null;
    public enum Slot { ELEMENT, PRODUCT };
    public Slot elementType = Slot.ELEMENT;
    public string draggedElement;

    GameObject placeholder = null ;

    public void OnBeginDrag(PointerEventData eventData)
    {

        //To maintain order of Objects

        placeholder = new GameObject();
        placeholder.transform.SetParent(this.transform.parent);
        LayoutElement le = placeholder.AddComponent<LayoutElement>();
       
        le.preferredWidth = this.GetComponent<LayoutElement>().preferredWidth;
        le.preferredHeight = this.GetComponent<LayoutElement>().preferredHeight;
        le.flexibleHeight = 0;
        le.flexibleWidth = 0;

        placeholder.transform.SetSiblingIndex(this.transform.GetSiblingIndex());

        //List<RaycastResult> results = new List<RaycastResult>();
        //EventSystem.current.RaycastAll(eventData, results);

        //if (results.Count > 0)
        //{
            //Error fixed by unchecking Panel raycast target
            //Debug.Log("Clicked on: " + results[0]);
        //    if (results[0].gameObject.GetComponent<Text>().text != null)
        //    {
        //        draggedElement = results[0].gameObject.GetComponent<Text>().text;
                //Debug.Log("Dragging Element: " + draggedElement);
        //    }


        //}

        parentToReturnTo = this.transform.parent; //Original parent of this object
        //Debug.Log(parentToReturnTo.ToString());
        this.transform.SetParent(this.transform.parent.parent); //Temporarily make this Object's parent as Canvas
        GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        //Debug.Log("OnDrag");

        this.transform.position = eventData.position;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        //Debug.Log("OnEndDrag");
        this.transform.SetParent(parentToReturnTo);
        this.transform.SetSiblingIndex(placeholder.transform.GetSiblingIndex());
        GetComponent<CanvasGroup>().blocksRaycasts = true;
        Destroy(placeholder);
    }
}

