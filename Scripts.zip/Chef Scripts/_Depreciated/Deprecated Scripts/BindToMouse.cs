﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BindToMouse : MonoBehaviour {

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update () {
        GetComponent<Transform>().position = Input.mousePosition;
    }
}
