﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ElementPanel : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{

    public enum Slot { ELEMENT, SYNTHESIS, PRODUCT, RECIPE }
    public Slot panelType = Slot.ELEMENT;
    public static Hashtable elementMap = new Hashtable();

    //Implements what happens when drop a Draggable dragged Object onto an ElementPanel Panel.
    public void OnDrop(PointerEventData eventData)
    {
        //Debug.Log(eventData.pointerDrag.name + " OnDrop to " + gameObject.name);


        ElementDraggable draggedElement = eventData.pointerDrag.GetComponent<ElementDraggable>(); //Object that is being dragged.
        GameObject draggedObject = eventData.pointerDrag;
        //Debug.Log(draggedObject);
        if (draggedElement != null)
        {
            string currentPanelType = panelType.ToString(); // Type of Panel
           // Debug.Log(currentPanelType);
            string draggedString = draggedElement.elementType.ToString(); //Type of Object
            //Debug.Log(draggedElement);

            if (currentPanelType.Equals(draggedString))
            {
                draggedElement.parentToReturnTo = this.transform; //Sets parent of dragged Object Draggable to this Panel
                //GameObject objParent = d.gameObject;
                //Debug.Log("objParent is " + objParent);
            }
            else if (currentPanelType.Equals("SYNTHESIS"))
            {
                //draggedObject.parentToReturnTo = this.transform;
                //Implementation of quantity decrease
                ElementDisplay elementDisplay = draggedObject.GetComponent<ElementDisplay>();
                string displayTextStr = elementDisplay.quantityText.text;
                int displayInt = int.Parse(displayTextStr);


                //Cloning object in Synthesis Panel
                //Allow if quantity >= 0
                if (displayInt > 0)
                {
                    GameObject cloneDragged = Instantiate(GameObject.Find(draggedObject.name + "0"));
                    //ElementDisplay cloneDisplay = cloneDragged.GetComponent<ElementDisplay>();
                    //Debug.Log("before:" + cloneDisplay.quantityText.text);
                    //cloneDisplay.quantityText.text = "";
                    //cloneDragged.GetComponent<ElementDisplay>().quantityText.text = "";
                    //Debug.Log("after" + cloneDisplay.quantityText.text);
                    cloneDragged.transform.SetParent(this.transform);

                    displayInt -= 1;
                    string displayString = displayInt.ToString();
                    elementDisplay.quantityText.text = displayString;
                }
                else
                {
                    Debug.Log("Ran out of: " + draggedObject.name);
                }

                string elementTag = draggedElement.tag;
                //Debug.Log(elementMap);
                if (!elementMap.Contains(elementTag))
                {
                    elementMap.Add(elementTag, 1);
                }
                else
                {
                    elementMap[elementTag] = (int)elementMap[elementTag] + 1;
                }
                /*
                foreach (DictionaryEntry e in elementMap)
                {
                    Debug.Log(e.Key);
                    Debug.Log(e.Value);
                }
                */
            }
            else
            {
                Debug.Log("Dragged Object type and Panel Type not compatible");
            }
        }

        

    }


    //Implement if want to add effects when scrolling pointer through Panels
    public void OnPointerEnter(PointerEventData eventData)
    {
        //Debug.Log("OnPointerEnter" + gameObject.name);
    }

    //Implement if want to add effects when scrolling pointer through Panels
    public void OnPointerExit(PointerEventData eventData)
    {
        //Debug.Log("OnPointerExit" + gameObject.name);
    }
}
