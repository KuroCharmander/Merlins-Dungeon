﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonDisplay : MonoBehaviour {

    public CustomButton button;

    public Text buttonNameText;
    public Image backgroundImage;

    // Use this for initialization
	void Start () {

        buttonNameText.text = button.buttonName;
        backgroundImage.sprite = button.background;
    
    }
	
}
