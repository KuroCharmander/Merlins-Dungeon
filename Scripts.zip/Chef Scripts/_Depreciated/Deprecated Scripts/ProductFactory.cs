﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProductFactory : MonoBehaviour {

    //public static List<Hashtable> moleculeList = new List<Hashtable>();

    // both reference the saame index
    public List<string> moleculeNames = new List<string>(); //list of names
    public List<Hashtable> moleculeList = new List<Hashtable>(); //list of the actual molecules
    public List<int> randomizedOrder = new List<int>();
    public int numElements;
    public int level = 0; // todo: change to actual levels after prefabs are made

    // common atoms
    string H = "Hydrogen";
    string O = "Oxygen";
    string C = "Carbon";
    string N = "Nitrogen";

    // common halogens
    string F = "Fluorine";
    string Cl = "Chlorine";
    string Br = "Bromine";
    string I = "Iodine";

    // common alkaline
    string Li = "Lithium";
    string Na = "Sodium";
    string K = "Potassium";

    // common earth alkaline
    string Ca = "Calsium";
    string Mg = "Magnesium";

    // common Boron group/group 3
    string B = "Boron";
    string Al = "Aluminum";
    string P = "Phosphorus";
    string S = "Sulphur";

    // important transitional metals
    string Fe = "Iron";
    string Co = "Cobalt";
    string Ni = "Nickel";
    string Cu = "Copper";
    string Zn = "Zinc";
    string Ag = "Silver";
    string Pt = "Platinum";
    string Au = "Gold";
    string Hg = "Mercury";
    string Pb = "Lead";


    public void RandomizeMolecules()
    {
        InitializeMoleculeList();

        numElements = (int)System.Math.Ceiling(moleculeNames.Capacity * 1.5);
        for (int i = 0; i < numElements; i++)
        {
            randomizedOrder.Add(Random.Range(0, moleculeNames.Capacity));
            Debug.Log(randomizedOrder[i]);
            Debug.Log(moleculeNames[randomizedOrder[i]]);
        }
    }

	// Use this for initialization
	public void InitializeMoleculeList()
    {
        OldLevel();
        switch (level)
        {
            case 1:
                Level1();
                break;
            case 2:
                Level2();
                break;
            case 3:
                break;
        }
    }

    private void OldLevel()
    {
        Hashtable H2O = new Hashtable();
        H2O[H] = 2;
        H2O[O] = 1;
        AddMolecule("Water", H2O); //index 0

        Hashtable CO2 = new Hashtable();
        CO2[C] = 1;
        CO2[O] = 2;
        AddMolecule("Carbon Dioxide", CO2); //index 1

        Hashtable H2CO3 = new Hashtable();
        H2CO3[H] = 2;
        H2CO3[C] = 1;
        H2CO3[O] = 3;
        AddMolecule("Carbonic Acid", H2CO3); //index 2

        Hashtable H2SO4 = new Hashtable();
        H2SO4[H] = 2;
        H2SO4[S] = 1;
        H2SO4[O] = 4;
        AddMolecule("Sulphuric Acid", H2SO4); //index 3
    }

    private void Level1()
    {
        Hashtable H2O = new Hashtable();
        H2O[H] = 2;
        H2O[O] = 1;
        AddMolecule("Water", H2O); //index 0

        Hashtable H2 = new Hashtable();
        H2[H] = 2;
        AddMolecule("Hydrogen Gas", H2); //index 1

        Hashtable O2 = new Hashtable();
        O2[O] = 2;
        AddMolecule("Oxygen Gas", O2); //index 2

        Hashtable CO2 = new Hashtable();
        CO2[C] = 1;
        CO2[O] = 2;
        AddMolecule("Carbon Dioxide", CO2); //index 3
    }

    private void Level2()
    {
        Hashtable NaCl = new Hashtable();
        NaCl[Na] = 1;
        NaCl[Cl] = 1;
        AddMolecule("Sodium Chloride", NaCl); //index 0

        Hashtable MgCl2 = new Hashtable();
        MgCl2[Mg] = 1;
        MgCl2[Cl] = 2;
        AddMolecule("Magnesium Chloride", MgCl2); //index 1

        Hashtable Al2O3 = new Hashtable();
        Al2O3[Al] = 2;
        Al2O3[O] = 3;
        AddMolecule("Aluminum Oxide", Al2O3); //index 2

        Hashtable CaO = new Hashtable();
        CaO[Ca] = 1;
        CaO[O] = 1;
        AddMolecule("Calcium Oxide", CaO); //index 3

        Hashtable LiF = new Hashtable();
        LiF[Li] = 1;
        LiF[F] = 1;
        AddMolecule("Lithium Fluoride", LiF); //index 4

        Hashtable LiBr = new Hashtable();
        LiBr[Li] = 1;
        LiBr[Br] = 1;
        AddMolecule("Lithium Bromide", LiBr); //index 5

        Hashtable KI = new Hashtable();
        KI[K] = 1;
        KI[I] = 1;
        AddMolecule("Potassium Iodide", KI); //index 7
    }

    // add the properties to the lists
    void AddMolecule(string name, Hashtable molecule)
    {
        moleculeNames.Add(name);
        moleculeList.Add(molecule);
    }
}
