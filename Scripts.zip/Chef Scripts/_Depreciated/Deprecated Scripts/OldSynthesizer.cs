﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class OldSynthesizer : MonoBehaviour, IPointerDownHandler
{

    SceneChange sceneChange = new SceneChange();

    LevelFactory levels = new LevelFactory();
    public static int lvl = 1; // todo: change to actual levels after prefabs are made

    private int score;
    public Text scoreText;
    float levelLoadDelay = 2f;

    int order = 0;

    // Use this for initialization
    void Start()
    {
        levels.InitializeMoleculeList(lvl);

        if (levels.randomize)
        {
            score = 0;
            SetScoreText();
            levels.RandomizeMolecules();
            InstantiateNext();
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        CheckSynthesis();
        //PanelObjects.ClearSynthesisPanel();
    }

    void CheckSynthesis()
    {
        // check if the elements entered matches the molecule
        int moleculeIndex = (levels.randomize) ? levels.randomizedOrder[order] : order;
        string moleculeName = levels.moleculeNames[moleculeIndex];
        Hashtable molecule = levels.moleculeList[moleculeIndex];

        if ((char)moleculeName[moleculeName.Length - 1] == '*')
        {
            List<string> reagents = (List<string>)molecule["Reagents"];
            Synthesize(reagents);
        }
        else
        {
            Synthesize(molecule, moleculeName);
        }
    }

    void Synthesize(List<string> reagents)
    {
        int count = reagents.Capacity;
        int i = 0;

        foreach (string e in ElementHandler.elementMap.Keys)
        {
            if (reagents.Contains(e))
            {
                reagents.Remove(e);
                i++;
            }
            else
            {
                break;
            }
        }

        if (count == i)
        {
            Debug.Log("Successfully Synthesized!");

            foreach (string e in ElementHandler.elementMap.Keys)
            {
                if (levels.randomize)
                    RandomMoleculeSuccess(e);
                else
                    PanelObjects.InstantiateProduct(e, "Element");
            }

            order++;
            if (levels.randomize) InstantiateNext();
        }
        else
        {
            FailSequence();
        }
    }

    void Synthesize(Hashtable molecule, string moleculeName)
    {
        int count = molecule.Count;
        int i = 0;
        foreach (string e in ElementHandler.elementMap.Keys)
        {
            if (molecule.ContainsKey(e) && (int)molecule[e] == (int)ElementHandler.elementMap[e])
                i++;
            else
                break;
        }

        if (count == i)
        {
            Debug.Log("Successfully Synthesized!");
            order++;
            if (levels.randomize)
            {
                RandomMoleculeSuccess(moleculeName);
                InstantiateNext();
            }
            else
            {
                PanelObjects.InstantiateProduct(moleculeName, "Elements");
            }
        }
        else
        {
            FailSequence();
        }
    }

    private void FailSequence()
    {
        Debug.Log("Failed");
        if (levels.randomize) RandomMoleculeFail();
        StartCoroutine(SpecialFX.FailColourBlink());
    }

    // =============================== RANDOMIZE LEVEL ======================================

    public void SetScoreText()
    {
        scoreText.text = "Score: " + score.ToString();
    }

    private void InstantiateNext()
    {
        if (order < levels.numElements)
        {
            string molecule = levels.moleculeNames[levels.randomizedOrder[order]];
            PanelObjects.InstantiateProduct(molecule, "Product");
        }
        else
        {
            sceneChange.LevelComplete();
        }
    }

    private void RandomMoleculeSuccess(string moleculeName)
    {
        score++;
        SetScoreText();
        GameObject deletedMolecule = GameObject.Find(moleculeName + "(Clone)");
        Destroy(deletedMolecule);
    }

    private void RandomMoleculeFail()
    {
        score--;
        SetScoreText();
    }
}
