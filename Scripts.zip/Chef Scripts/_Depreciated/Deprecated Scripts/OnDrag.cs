﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnDrag : MonoBehaviour {

    public GameObject cursor;
    private Transform OGParent;

    private void Start()
    {
        OGParent = GetComponent<Transform>().parent;
    }

    private void OnMouseDrag()
    {
        Debug.Log("DID");
        GetComponent<Transform>().SetParent(cursor.GetComponent<Transform>());
    }

    private void OnMouseUp()
    {
        GetComponent<Transform>().SetParent(OGParent);
    }
}
