﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Product : MonoBehaviour, IPointerDownHandler {

    int order = 0;
    ProductFactory products = new ProductFactory();
    private int Score;
    public Text ScoreText;
    float levelLoadDelay = 2f;


    public void Start()
    {
        Score = 0;
        SetScoreText();
        products.RandomizeMolecules();
        string firstMolecule = products.moleculeNames[products.randomizedOrder[order]];
        PanelObjects.InstantiateProduct(firstMolecule, "Product");
    }

    public void SetScoreText()
    {
        ScoreText.text = "Score: " + Score.ToString();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        CheckSynthesis();
        //PanelObjects.ClearSynthesisPanel();     
    }

    void CheckSynthesis()
    {
        // using the randomized order, check if the elements entered matches the molecule
        int moleculeIndex = products.randomizedOrder[order];
        string moleculeName = products.moleculeNames[moleculeIndex];
        Hashtable molecule = products.moleculeList[moleculeIndex];
        if (SynthesizeHelper(molecule))
        {
            Debug.Log("Successfully Synthesized!");
            Score++;
            SetScoreText();
            GameObject deletedMolecule = GameObject.Find(moleculeName + "(Clone)");
            Destroy(deletedMolecule);
            order++;
            if (order < products.numElements)
            {
                PanelObjects.InstantiateProduct(products.moleculeNames[products.randomizedOrder[order]], "Product");
            }
            else
            {
                // when all the orders are finished, restart the game (for now)
                // todo: change to load next level
                Debug.Log("You win!");
                //Application.Quit();
                Invoke("LoadFirstLevel", levelLoadDelay);
            }
        }
        else
        {
            Debug.Log("Failed");
            Score -= 1;
            SetScoreText();

            //Need to wait here
            StartCoroutine(SpecialFX.FailColourBlink());
        }
    }

    // restarts the game
    private void LoadFirstLevel()
    {
        SceneManager.LoadScene(0);
    }

    bool SynthesizeHelper(Hashtable molecule)
    {
        int count = molecule.Count;
        int i = 0;
        foreach (string e in ElementPanel.elementMap.Keys)
        {
            if (molecule.ContainsKey(e) && (int)molecule[e] == (int)ElementPanel.elementMap[e])
            {
                i++;
            }
            else
            {
                return false;
            }
        }
        return count == i;
    }

}
