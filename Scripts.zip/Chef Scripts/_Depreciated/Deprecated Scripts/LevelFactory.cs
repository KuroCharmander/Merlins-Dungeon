﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelFactory : MonoBehaviour
{

    // both reference the same index
    public List<string> moleculeNames = new List<string>(); //list of names
    public List<Hashtable> moleculeList = new List<Hashtable>(); //list of the actual molecules

    // randomizing "boss" levels
    public List<int> randomizedOrder = new List<int>();
    public int numElements; // number of elements in randomizedOrder
    public bool randomize = false;

    string Reagents = "Reagents";

    // common atoms
    string H = "Hydrogen";
    string O = "Oxygen";
    string C = "Carbon";
    string N = "Nitrogen";

    string OH = "Hydroxide";

    // common halogens
    string F = "Fluorine";
    string Cl = "Chlorine";
    string Br = "Bromine";
    string I = "Iodine";

    // common alkaline
    string Li = "Lithium";
    string Na = "Sodium";
    string K = "Potassium";

    // common earth alkaline
    string Ca = "Calsium";
    string Mg = "Magnesium";

    // common Boron group/group 3
    string B = "Boron";
    string Al = "Aluminum";
    string P = "Phosphorus";
    string S = "Sulphur";

    // important transitional metals
    string Fe = "Iron";
    string Co = "Cobalt";
    string Ni = "Nickel";
    string Cu = "Copper";
    string Zn = "Zinc";
    string Ag = "Silver";
    string Pt = "Platinum";
    string Au = "Gold";
    string Hg = "Mercury";
    string Pb = "Lead";

    // Use this for initialization
    public void InitializeMoleculeList(int lvl)
    {
        switch (lvl)
        {
            case 1:
                Level1();
                break;
            case 2:
                Level2();
                break;
            case 3:
                Level3();
                break;
            case 4:
                Level4();
                break;
            case 5:
                Level5();
                break;
        }
    }

    public void RandomizeMolecules()
    {
        numElements = (int)System.Math.Ceiling(moleculeNames.Capacity * 1.5);
        for (int i = 0; i < numElements; i++)
        {
            randomizedOrder.Add(Random.Range(0, moleculeNames.Capacity));
            Debug.Log(randomizedOrder[i]);
            Debug.Log(moleculeNames[randomizedOrder[i]]);
        }
    }

    // add the properties to the lists
    void AddMolecule(string name, Hashtable molecule)
    {
        moleculeNames.Add(name);
        moleculeList.Add(molecule);
    }

    private void Level1()
    {
        Hashtable O2 = new Hashtable();
        O2[O] = 2;
        AddMolecule("Oxygen Gas", O2);

        randomize = false;
    }

    private void Level2()
    {
        Hashtable HCl = new Hashtable();
        HCl[H] = 1;
        HCl[Cl] = 1;
        AddMolecule("Hydrochloric Acid", HCl);

        randomize = false;
    }

    private void Level3()
    {
        Hashtable NaOH = new Hashtable();
        NaOH[Na] = 1;
        NaOH[OH] = 1;
        AddMolecule("Sodium Hydroxide", NaOH); //index 2

        randomize = false;
    }

    private void Level4()
    {
        Level2();
        Level3();

        Hashtable H2O = new Hashtable();
        H2O[H] = 2;
        H2O[O] = 1;
        //AddMolecule("Water", H2O);

        Hashtable NaCl = new Hashtable();
        NaCl[Na] = 1;
        NaCl[Cl] = 1;
        //AddMolecule("Sodium Chloride", NaCl);

        Hashtable Neutralization = new Hashtable();
        Neutralization.Add(Reagents, new Hashtable());
        ((List<string>)Neutralization["Reagents"]).Add("Hydrochloric Acid");
        ((List<string>)Neutralization["Reagents"]).Add("Sodium Hydroxide");

        Neutralization["Water"] = H2O;
        Neutralization["Sodium Chloride"] = H2O;
        AddMolecule("R1P2*", Neutralization);

        randomize = false;
    }

    private void Level5()
    {
        Level1();
        Level2();
        Level3();
        Level4();
        randomize = true;
    }
}
