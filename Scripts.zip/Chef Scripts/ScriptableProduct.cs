﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "New Product", menuName = "Product")]
public class ScriptableProduct : ScriptableObject {

    public string productName;
    public Sprite background;
}
