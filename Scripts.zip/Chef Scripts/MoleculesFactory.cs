﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoleculesFactory : MonoBehaviour {

    // For the molecules themselves
    public Dictionary<string, Dictionary<string, int>> molecules 
        = new Dictionary<string, Dictionary<string, int>>();

    // For the reactions only
    public Dictionary<int, Dictionary<int, Dictionary<string, int>>> reactions 
        = new Dictionary<int, Dictionary<int, Dictionary<string, int>>>();

    int Reactants = 1;
    int Products = 2;

    // common atoms
    string H = "Hydrogen";
    string O = "Oxygen";
    string C = "Carbon";
    string N = "Nitrogen";

    string OH = "Hydroxide";

    // common halogens
    string F = "Fluorine";
    string Cl = "Chlorine";
    string Br = "Bromine";
    string I = "Iodine";

    // common alkaline
    string Li = "Lithium";
    string Na = "Sodium";
    string K = "Potassium";

    /*
    // common earth alkaline
    string Ca = "Calsium";
    string Mg = "Magnesium";

    // common Boron group/group 3
    string B = "Boron";
    string Al = "Aluminum";
    string P = "Phosphorus";
    string S = "Sulphur";

    // important transitional metals
    string Fe = "Iron";
    string Co = "Cobalt";
    string Ni = "Nickel";
    string Cu = "Copper";
    string Zn = "Zinc";
    string Ag = "Silver";
    string Pt = "Platinum";
    string Au = "Gold";
    string Hg = "Mercury";
    string Pb = "Lead";
    */

    public void InitializeMoleculeList()
    {
        Dictionary<string, int> H2O = new Dictionary<string, int>
        {   { H, 2 },
            { O, 1 }    };
        molecules.Add("Water", H2O);

        Dictionary<string, int> O2 = new Dictionary<string, int>
        {   { O, 2 }    };
        molecules.Add("Oxygen Gas", O2);

        Dictionary<string, int> HCl = new Dictionary<string, int>
        {   { H, 1 },
            { Cl, 1 }   };
        molecules.Add("Hydrochloric Acid", HCl);

        Dictionary<string, int> NaOH = new Dictionary<string, int>
        {   { Na, 1 },
            { OH, 1 }   };
        molecules.Add("Sodium Hydroxide", NaOH); //index 2

        Dictionary<string, int> NaCl = new Dictionary<string, int>
        {   { Na, 1 },
            { Cl, 1 }   };
        molecules.Add("Sodium Chloride", NaCl);

        Dictionary<int, Dictionary<string, int>> Neutralization 
            = new Dictionary<int, Dictionary<string, int>>
        {
            { Reactants, new Dictionary<string, int>
                {   { "Hydrochloric Acid", 1 },
                    { "Sodium Hydroxide", 1}    }
            },
            { Products, new Dictionary<string, int>
                {   { "Water", 1 },
                    { "Sodium Chloride", 1 }    }
            }
        };
        reactions.Add(0, Neutralization);

    }
}
