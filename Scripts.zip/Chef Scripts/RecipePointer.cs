﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class RecipePointer : MonoBehaviour , IPointerEnterHandler, IPointerExitHandler
{

    public GameObject scienceText;
    public static bool hovered = false;

	// Use this for initialization
	void Start () {
        scienceText.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    //Implement if want to add effects when scrolling pointer through Panels
    public void OnPointerEnter(PointerEventData eventData)
    {
        //Debug.Log("OnPointerEnter" + gameObject.name);
        scienceText.SetActive(true);
        hovered = true;
    }

    //Implement if want to add effects when scrolling pointer through Panels
    public void OnPointerExit(PointerEventData eventData)
    {
        //Debug.Log("OnPointerExit" + gameObject.name);
        scienceText.SetActive(false);
    }
}
