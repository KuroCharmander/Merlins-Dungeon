﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpecialFX : MonoBehaviour
{
    static int numBlink = 2;
    static float blinkDelay = 0.2f;

    public static IEnumerator FailColourBlink()
    {
        Image synthesisPanel = GameObject.Find("Synthesis").GetComponent<Image>();

        if (synthesisPanel.color != Color.red)
        {
            Color originalColor = synthesisPanel.color;


            for (int i = 0; i <= numBlink; i++)
            {
                synthesisPanel.color = Color.red;
                yield return new WaitForSeconds(blinkDelay);
                synthesisPanel.color = originalColor;
                yield return new WaitForSeconds(blinkDelay);
            }
        }
    }

    //TODO: fix after checking synthesis is elsewhere
    public static IEnumerator ColourBlink(GameObject product)
    {
        Debug.Log("Colour Blink");

        Button productImage = product.GetComponent<Button>();
        /*
        if (productImage.color != Color.green)
        {
            Color originalColor = productImage.color;
        */    
            for (int i = 0; i <= numBlink; i++)
            {
                productImage.GetComponent<Image>().color = Color.grey;
            Debug.Log(productImage.GetComponent<Image>().color);
                yield return new WaitForSeconds(blinkDelay);
                //productImage.color = originalColor;
                yield return new WaitForSeconds(blinkDelay);
            }
        //}
    }

    public static void ColourChange(GameObject product)
    {
        Image productImage = product.GetComponent<Image>();
        productImage.color = Color.green;
    }
}
