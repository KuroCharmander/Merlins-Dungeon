﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {

    public Image timer;
    float time;
    public bool gamePaused = false;
    public float waitTime = 10.0f;

    // Update is called once per frame
    void Update()
    {
        if (gamePaused == false && time < waitTime)
        {
            //Reduce fill amount over 60 seconds
            timer.fillAmount -= 1.0f / waitTime * Time.deltaTime;
            time += Time.deltaTime;
            //Debug.Log(time);
        }
        else
        {
            // todo: change to "Failed" screen
            GameObject canvas = GameObject.Find("Canvas");
            canvas.SetActive(false);
        }
    }
}
