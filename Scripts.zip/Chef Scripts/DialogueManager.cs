﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class DialogueManager : MonoBehaviour
{

    DialogueParser parser;

    public string dialogue, characterName;
    public int lineNum;
    int pose;
    string position;
    string[] options;
    public bool playerTalking;
    List<Button> buttons = new List<Button>();

    //For level 2 Crafting activation after dialoge
    bool firstDialogue = false;
    bool doneSecondDialogue = false;

    public Text dialogueBox;
    public Text nameBox;
    public GameObject choiceBox;
    SceneChange sceneChange = new SceneChange();

    GameObject player;

    public GameObject skipText;
    public GameObject clickText;


    // Use this for initialization
    public void BeginDialogue(GameObject sign, GameObject p)
    {
        dialogue = "";
        characterName = "";
        pose = 0;
        position = "L";
        playerTalking = false;

        clickText.SetActive(false);

        player = p;
        parser = sign.GetComponent<DialogueParser>();
        //Debug.Log(parser);

        parser.Parse();
        lineNum = 0;

        ShowDialogue();
        lineNum++;
    }

    // Update is called once per frame
    void Update()
    {
        if (lineNum > parser.GetNumLines() | Input.GetKeyDown(KeyCode.F))
        {

            ResetImages();
            player.SetActive(true);
            //Debug.Log("player activated");
            GameObject.Find("Dialogue Panel").gameObject.SetActive(false);

            //Brings objects to original layers
            if (GameObject.Find("Crafting Panels") == null) //For level 1 only
            {
                GameObjectActions.ResetPlayableObjects();
            }
            else if (GameObject.Find("Crafting Panels").transform.Find("Synthesis") != null) 
            {
                if (!GameObject.Find("Crafting Panels").transform.Find("Synthesis").gameObject.activeSelf)
                {
                    GameObjectActions.ResetPlayableObjects();
                }
            }
            //GameObjectActions.ResetPlayableObjects();

            /*Transform playableObjects = GameObject.Find("Playable Objects").transform;
            foreach (Transform item in playableObjects)
            {
                if (item.name.Equals("Player"))
                {
                    item.GetComponent<SpriteRenderer>().sortingOrder = 2;
                }
                else
                {
                    item.GetComponent<SpriteRenderer>().sortingOrder = 1;
                }
            }*/
            if (sceneChange.GetCurrentSceneIndex() == 1) 
            {
                if (!firstDialogue)
                {
                    firstDialogue = true;
                }
                else
                {
                    if (!doneSecondDialogue)
                    {
                        GameObjectActions.EnableCrafting(true);
                        GameObject.Find("Player").SetActive(false);
                        PlayerInteract.levelTwoObject.SendMessage("DeactivatePopUp");
                        doneSecondDialogue = true;
                    }
                }
            }

            if (PlayerInteract.activatedCorrectDialogue)
            {
                if (sceneChange.GetCurrentSceneIndex() == 2)
                {
                    GameObjectActions.ShowObstaclePopup("Fire");
                }
                else if (sceneChange.GetCurrentSceneIndex() == 3)
                {
                    GameObjectActions.ShowObstaclePopup("Snowman");
                }
            }
        } else if ((Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space)) 
            && playerTalking == false)
        {
            ShowDialogue();
            lineNum++;
        }

        UpdateUI();

        
    }

    public void ShowDialogue()
    {
        ResetImages();
        ParseLine();
    }

    void UpdateUI()
    {
        if (!playerTalking)
        {
            ClearButtons();
            SetPromptTextActive(true, false);
        }
        dialogueBox.text = dialogue;
        nameBox.text = characterName;
    }

    void ClearButtons()
    {
        for (int i = 0; i < buttons.Count; i++)
        {
            print("Clearing buttons");
            Button b = buttons[i];
            buttons.Remove(b);
            Destroy(b.gameObject);
        }
    }

    void ParseLine()
    {
        if (parser.GetName(lineNum) != "Player")
        {
            playerTalking = false;
            characterName = parser.GetName(lineNum);
            dialogue = parser.GetContent(lineNum);
            pose = parser.GetPose(lineNum);
            position = parser.GetPosition(lineNum);
            DisplayImages();
        }
        else
        {
            playerTalking = true;
            characterName = "";
            dialogue = "";
            pose = 0;
            position = "";
            options = parser.GetOptions(lineNum);
            CreateButtons();
            SetPromptTextActive(false, true);
        }
    }

    void CreateButtons()
    {
        for (int i = 0; i < options.Length; i++)
        {
            GameObject button = (GameObject)Instantiate(choiceBox);
            Button b = button.GetComponent<Button>();
            ChoiceButton cb = button.GetComponent<ChoiceButton>();
            cb.SetText(options[i].Split(':')[0]);
            cb.option = options[i].Split(':')[1];
            cb.box = this;
            b.transform.SetParent(this.transform);
            b.transform.localPosition = new Vector3(0, (-25 + (i * 50)) * 1.5f);
            b.transform.localScale = new Vector3(1.5f, 1.5f, 1);
            buttons.Add(b);
        }
    }

    void SetPromptTextActive(bool skipActive, bool clickActive)
    {
        skipText.SetActive(skipActive);
        clickText.SetActive(clickActive);
    }

    void ResetImages()
    {
        if (characterName != "")
        {
            GameObject character = GameObject.Find(characterName);
            SpriteRenderer currSprite = character.GetComponent<SpriteRenderer>();
            currSprite.sprite = null;
        }
    }

    void DisplayImages()
    {
        if (characterName != "")
        {
            GameObject character = GameObject.Find(characterName);

            SetSpritePositions(character);

            SpriteRenderer currSprite = character.GetComponent<SpriteRenderer>();
            currSprite.sprite = character.GetComponent<Character>().characterPoses[pose];
        }
    }


    void SetSpritePositions(GameObject spriteObj)
    {
        if (position == "L")
        {
            spriteObj.transform.position = new Vector3(-125, 30);
        }
        else if (position == "R")
        {
            spriteObj.transform.position = new Vector3(125, 30);
        }
        else if (position == "C")
        {
            spriteObj.transform.position = new Vector3(0, 20);
        }
        spriteObj.transform.position = new Vector3(spriteObj.transform.position.x, spriteObj.transform.position.y, 0);
    }
}
