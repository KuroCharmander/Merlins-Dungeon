﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameObjectActions : MonoBehaviour
{
    public static string[] craftingNames = { "Synthesis", "Recipes", "Synthesize Button" };
    public static GameObject[] craftingObjects;

    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    static void InstantiateObjects()
    {
        for (int i = 0; i < craftingNames.Length; i++)
        {
            craftingObjects[i] = GameObject.Find("Crafting Panels").transform.Find(craftingNames[i]).gameObject;
        }
    }

    public static void EnableCrafting(bool active)
    {
        //InstantiateObjects();
        //foreach (GameObject o in craftingObjects)
        //    o.SetActive(active);

        GameObject.Find("Crafting Panels").transform.Find("Synthesis").gameObject.SetActive(active);
        GameObject.Find("Crafting Panels").transform.Find("Recipes").gameObject.SetActive(active);
        GameObject.Find("Crafting Panels").transform.Find("Synthesize Button").gameObject.SetActive(active);
        GameObject.Find("Crafting Panels").transform.Find("Exit Button").gameObject.SetActive(active);

        if (active) 
        {
            //GameObject.Find("Player").SetActive(false);
            Transform playableObjects = GameObject.Find("Playable Objects").transform;
            foreach (Transform item in playableObjects)
            {
                item.GetComponent<SpriteRenderer>().sortingOrder = 0;
            }

            Transform fluffObjects = GameObject.Find("BringToBack").transform;
            foreach (Transform item in fluffObjects)
            {
                if (item.name.Equals("Snow"))
                {
                    item.GetComponent<ParticleSystemRenderer>().sortingOrder = 0;
                }
                else
                {
                    item.GetComponent<SpriteRenderer>().sortingOrder = 0;
                }
            }
        }

    }

    public static void ResetPlayableObjects()
    {
        Transform playableObjects = GameObject.Find("Playable Objects").transform;
        foreach (Transform item in playableObjects)
        {
            if (item.name.Equals("Player"))
            {
                item.GetComponent<SpriteRenderer>().sortingOrder = 2;
            }
            else
            {
                item.GetComponent<SpriteRenderer>().sortingOrder = 1;
            }
        }
        Transform fluffObjects = GameObject.Find("BringToBack").transform;
        foreach (Transform item in fluffObjects)
        {
            if (item.name.Equals("Snow")) //Snow uses particle system instead of sprite renderer
            {
                item.GetComponent<ParticleSystemRenderer>().sortingOrder = 1;
            }
            else
            {
                item.GetComponent<SpriteRenderer>().sortingOrder = 2;
            }
 
        }
    }

    public static void HideObstaclePopup(string enemy)
    {
        GameObject obstacle = GameObject.Find("Playable Objects").transform.Find(enemy).gameObject;
        obstacle.transform.GetChild(0).gameObject.SetActive(false);
    }

    public static void ShowObstaclePopup(string enemy)
    {
        GameObject obstacle = GameObject.Find("Playable Objects").transform.Find(enemy).gameObject;
        obstacle.transform.GetChild(0).gameObject.SetActive(false);
    }
   

}
